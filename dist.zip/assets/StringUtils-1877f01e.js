function t(t,n){return t.toString().padStart(n,"0")}function n(t){return 1==t?"男":2==t?"女":"未知"}function r(t){return"男"==t?1:"女"==t?2:0}export{n as i,r as s,t};
