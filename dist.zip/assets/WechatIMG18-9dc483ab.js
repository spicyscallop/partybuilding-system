const a="/assets/WechatIMG20-2473d9aa.jpg",s="/assets/WechatIMG19-6b9af996.jpg",t="/assets/WechatIMG18-dc6a0215.jpg";export{a as _,s as a,t as b};
