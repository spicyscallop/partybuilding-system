import{a8 as e}from"./index-2c4a18b7.js";const o=e(Object.freeze(Object.defineProperty({__proto__:null,default:{}},Symbol.toStringTag,{value:"Module"})));export{o as r};
